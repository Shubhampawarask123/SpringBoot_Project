package com.training.ngo.dto;

public class NgoDto {
	private int ngoId;
	private String  ngoName;
	private String ngoBranch;
	private double balance;
	public int getNgoId() {
		return ngoId;
	}
	public void setNgoId(int ngoId) {
		this.ngoId = ngoId;
	}
	public String getNgoName() {
		return ngoName;
	}
	public void setNgoName(String ngoName) {
		this.ngoName = ngoName;
	}
	public String getNgoBranch() {
		return ngoBranch;
	}
	public void setNgoBranch(String ngoBranch) {
		this.ngoBranch = ngoBranch;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	

}
