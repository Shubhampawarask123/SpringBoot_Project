package com.training.ngo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.ngo.entity.Ngo;

public interface NgoRepository extends JpaRepository<Ngo, Integer> {

}
