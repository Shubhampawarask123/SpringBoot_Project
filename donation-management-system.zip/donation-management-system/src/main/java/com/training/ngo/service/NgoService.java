package com.training.ngo.service;

import java.util.List;

import com.training.ngo.dto.NgoDto;

public interface NgoService {
	public NgoDto saveNgo(NgoDto ngodto) ;
	public NgoDto deleteNgo(int id);
	public NgoDto getNgoById(int id);
	public NgoDto updateNgo(int id,NgoDto ngodto);
	public List<NgoDto> getAllNgos();
	

}
