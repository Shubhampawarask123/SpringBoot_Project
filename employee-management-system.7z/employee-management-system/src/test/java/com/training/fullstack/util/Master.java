package com.training.fullstack.util;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.training.fullstack.dto.EmployeeDto;

public class Master {
	public static EmployeeDto getEmployeeData() {

		EmployeeDto dto = new EmployeeDto();
		dto.setId(1);
		dto.setName("Rahul");
		dto.setEmail("rahuil@gmail.com");
		dto.setPhoneNumber(9087654322L);
		dto.setSalary(450000);
		dto.setDateOfjoining(LocalDate.of(2022, 10, 10));
		dto.setActive(true);
		return dto;

	}

	public static List<EmployeeDto> getEmployeeList() {

		List<EmployeeDto> dtos = new ArrayList<>();
		EmployeeDto dto = new EmployeeDto();
		dto.setId(1);
		dto.setName("Rahul");
		dto.setEmail("rahuil@gmail.com");
		dto.setPhoneNumber(9087654322L);
		dto.setSalary(450000);
		dto.setDateOfjoining(LocalDate.of(2022, 10, 10));
		dto.setActive(true);
		dtos.add(dto);

		dto.setId(2);
		dto.setName("Shubham");
		dto.setEmail("shubham@gmail.com");
		dto.setPhoneNumber(9087654322L);
		dto.setSalary(780000);
		dto.setDateOfjoining(LocalDate.of(2022, 10, 01));
		dto.setActive(true);

		dtos.add(dto);

		return dtos;

	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			mapper.registerModule(new JavaTimeModule());
			mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
			final String jsonContent = mapper.writeValueAsString(obj);

			return jsonContent;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
