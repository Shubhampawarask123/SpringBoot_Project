package com.training.fullstack.Exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.training.fullstack.dto.EmployeeDto;
import com.training.fullstack.service.EmployeeService;
import com.training.fullstack.util.Master;
@SpringBootTest
@AutoConfigureMockMvc
public class EmployeeExceptionTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private EmployeeService employeeService;

	@Test
	public void testRegisterEmpoyeeInvalidDataException() throws Exception {
		EmployeeDto employeeDto = Master.getEmployeeData();
		EmployeeDto savedEmployeeDto = Master.getEmployeeData();
		savedEmployeeDto.setId(1);
		employeeDto.setName("Ab");
		when(this.employeeService.saveEmployee(savedEmployeeDto)).thenReturn(savedEmployeeDto);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/employees")
				.content(Master.asJsonString(employeeDto)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		assertEquals("true", (result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"));

	}

}
