package com.training.fullstack.boundary;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.checkerframework.checker.units.qual.min;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.jayway.jsonpath.internal.function.numeric.Max;
import com.training.fullstack.dto.EmployeeDto;
import com.training.fullstack.util.Master;

@SpringBootTest
class EmployeeBoundaryTest {

	private static Validator validator;

	@BeforeAll
	public static void setUp() {
		ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
		validator = factory.getValidator();
	}

	@Test
	public void testEmployeeNameNotNull() throws Exception {
		EmployeeDto employeeDto = Master.getEmployeeData();
		employeeDto.setName("Shubham");
		Set<ConstraintViolation<EmployeeDto>> violations = validator.validate(employeeDto);
		assertEquals(true, violations.isEmpty());

	}
	@Test
	public void testEmployeeEmailNotNull() throws Exception {
		EmployeeDto employeeDto = Master.getEmployeeData();
		employeeDto.setEmail(null);
		Set<ConstraintViolation<EmployeeDto>> violations = validator.validate(employeeDto);
		assertEquals(true, violations.isEmpty());

	}
	@Test
	public void testEmployeeSalaryNotNull() throws Exception {
		EmployeeDto employeeDto = Master.getEmployeeData();
		employeeDto.setSalary(0.0);
		Set<ConstraintViolation<EmployeeDto>> violations = validator.validate(employeeDto);
		assertEquals(true, violations.isEmpty());

	}
	

}
