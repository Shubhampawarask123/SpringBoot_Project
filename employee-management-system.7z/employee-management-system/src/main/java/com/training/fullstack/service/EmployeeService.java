package com.training.fullstack.service;

import java.util.List;

import com.training.fullstack.dto.EmployeeDto;

public interface EmployeeService {

	public EmployeeDto saveEmployee(EmployeeDto employeeDto);
	public EmployeeDto updateEmployee(int id,EmployeeDto employeeDto);
	public EmployeeDto deleteEmployee(int  id);
	public EmployeeDto getEmployee(int id);
	public List<EmployeeDto> getAllEmployees();
	public EmployeeDto getEmployeeByName(String name);
	public Boolean existsByEmail(String email);
}
