package com.training.fullstack.dto;

import java.time.LocalDate;
import java.util.Objects;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.lang.NonNull;

import com.fasterxml.jackson.annotation.JsonFormat;

public class EmployeeDto {

	private int id;

	@NotBlank(message = "Please Enter the name")
	@Size(min = 3, max = 30, message = "The Name shouls be min 3 and max 50 charecter")
	private String name;

	@NotBlank(message = "Email filed should not be blank")
	@Email(message = "Please provide proper email address")
	private String email;

	@NonNull
	private double salary;
	
//	@NotBlank(message = "Please provide the date of joining")
	@Past(message = "The date should be past date")
	@JsonFormat(pattern = "dd-MM-yyyy")
	private LocalDate dateOfjoining;
	
	@NonNull
	private boolean active;
	
	@NotNull(message = "Please provide the Phone number")
//	@Pattern(regexp = "(^[7-9][0-9]{9}$)")
	private long phoneNumber;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public LocalDate getDateOfjoining() {
		return dateOfjoining;
	}

	public void setDateOfjoining(LocalDate dateOfjoining) {
		this.dateOfjoining = dateOfjoining;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public int hashCode() {
		return Objects.hash(active, dateOfjoining, email, id, name, phoneNumber, salary);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmployeeDto other = (EmployeeDto) obj;
		return active == other.active && Objects.equals(dateOfjoining, other.dateOfjoining)
				&& Objects.equals(email, other.email) && id == other.id && Objects.equals(name, other.name)
				&& phoneNumber == other.phoneNumber
				&& Double.doubleToLongBits(salary) == Double.doubleToLongBits(other.salary);
	}

	
	
}
