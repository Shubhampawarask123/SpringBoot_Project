package com.training.fullstack.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.training.fullstack.dto.EmployeeDto;
import com.training.fullstack.exception.EmployeeNotFoundException;
import com.training.fullstack.model.entity.Employee;
import com.training.fullstack.repository.EmployeeRepository;
import com.training.fullstack.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository repository;

	@Override
	public EmployeeDto saveEmployee(EmployeeDto employeeDto) {
		// TODO Auto-generated method stub
		if(existsByEmail(employeeDto.getEmail())) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Email already exists:"+employeeDto.getEmail());
		}
		Employee employee = new Employee();
		BeanUtils.copyProperties(employeeDto, employee);
		repository.save(employee);
		return employeeDto;
	}

	@Override
	public EmployeeDto updateEmployee(int id, EmployeeDto employeeDto) {
		// TODO Auto-generated method stub
		EmployeeDto employeedto1 = getEmployee(id);
		if (employeeDto.getName().equals(employeedto1.getName())) {
			Employee employee = new Employee();
			employeeDto.setId(id);
			BeanUtils.copyProperties(employeeDto, employee);
			repository.save(employee);
		}

		return employeeDto;
	}

	@Override
	public EmployeeDto deleteEmployee(int id) {
		EmployeeDto employeeDto = getEmployee(id);
		Employee employee = new Employee();
		BeanUtils.copyProperties(employeeDto, employee);
		repository.delete(employee);
		return employeeDto;
	}

	@Override
	public EmployeeDto getEmployee(int id) {
		Optional<Employee> findById = repository.findById(id);
		if (findById.isPresent()) {
			EmployeeDto dto = new EmployeeDto();
			BeanUtils.copyProperties(findById.get(), dto);
			return dto;
		}
		 throw new EmployeeNotFoundException("No Employee Found"+id); 
	}

	@Override
	public List<EmployeeDto> getAllEmployees() {
		List<Employee> list = repository.findAll();
		List<EmployeeDto> empdtoList = new ArrayList<>();
		for (Employee emp : list) {
			EmployeeDto dto = new EmployeeDto();
			BeanUtils.copyProperties(emp, dto);
			empdtoList.add(dto);

		}

		return empdtoList;
	}

	@Override
	public EmployeeDto getEmployeeByName(String name) {
		Optional<Employee> byName = repository.findByName(name);
		if (byName.isPresent()) {
			EmployeeDto dto = new EmployeeDto();
			BeanUtils.copyProperties(byName.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public Boolean existsByEmail(String email) {

		return repository.existsByEmail(email);
	}

}
