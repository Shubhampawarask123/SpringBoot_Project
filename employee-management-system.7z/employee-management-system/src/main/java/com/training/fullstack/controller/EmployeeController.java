package com.training.fullstack.controller;

import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.training.fullstack.dto.EmployeeDto;
import com.training.fullstack.service.EmployeeService;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
	@Autowired
	private EmployeeService service;

	@PostMapping()
	public ResponseEntity<EmployeeDto> saveEmployee(@Valid @RequestBody EmployeeDto dto) {
		EmployeeDto dto1 = service.saveEmployee(dto);
		return new ResponseEntity<EmployeeDto>(dto, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<EmployeeDto> getEmployee(@PathVariable int id) {
		EmployeeDto employeeDto = service.getEmployee(id);
		return new ResponseEntity<EmployeeDto>(employeeDto, HttpStatus.FOUND);
	}

	@GetMapping
	public ResponseEntity<List<EmployeeDto>> getAllEmployees() {
		List<EmployeeDto> employees = service.getAllEmployees();
		return new ResponseEntity<List<EmployeeDto>>(employees, HttpStatus.FOUND);

	}
	@DeleteMapping("/{id}")
	public ResponseEntity<EmployeeDto> deletEmployee(@PathVariable int id){
		EmployeeDto employeeDto= service.deleteEmployee(id);
		return new ResponseEntity<EmployeeDto>(employeeDto,HttpStatus.OK);
	}
	@PutMapping("/{id}")
	public ResponseEntity<EmployeeDto> updateEmployee (@Valid @PathVariable int id,@RequestBody EmployeeDto employeeDto){
		EmployeeDto employee = service.updateEmployee(id, employeeDto);
		return new ResponseEntity<EmployeeDto>(employee,HttpStatus.OK);
	}
	
	@GetMapping("/get-by-{name}")
	public ResponseEntity<EmployeeDto> getEmployeeByName(@PathVariable String name) {
		EmployeeDto employeeDto = service.getEmployeeByName(name);
		return new ResponseEntity<EmployeeDto>(employeeDto, HttpStatus.FOUND);
	}
}
